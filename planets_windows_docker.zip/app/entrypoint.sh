#!/bin/bash
set -e

# Set permissions
chmod -R 777 storage bootstrap/cache

# Run migrations
php artisan migrate --force

# Sync SWAPI
php artisan swapi:sync

# Start PHP-FPM in background
php-fpm &

# Start Vite dev server in background
npm run dev &

# Keep container running
tail -f /dev/null
